#!/bin/bash
flakeRate=0.0
if [ $# -lt 1 ]; then
    echo "No flakerate present setting to default 0.0"
else
    flakeRate=$1
fi


echo "Flake rate [${flakeRate}]"
rep=10
i=0
if [ $flakeRate == "0.0" ]; then
    rep=1;
fi

while [ $i -lt $rep ]; do
echo "#######################   Repetition [$i/$rep]"
MAVEN_OPTS=-Xss10m JAVA_HOME=/usr/java/jdk1.8.0_281/ \
   mvn clean org.mudebug:prapr-plugin:prapr \
   -Dflakime.flakeRate=${flakeRate} \
   -Dflakime.strategy=vocabulary;
    cat target/prapr-reports/**/fix-report.log | grep -E 'Plausible Fixes' | grep -o '[0-9]*' >> $flakeRate.log
    i=$((i+1))
done