#!/bin/bash
flakeRate=$1
echo "Flake rate [${flakeRate}]"
for i in {1..2}
do
    echo "Repetition $i";
    MAVEN_OPTS=-Xss10m JAVA_HOME=/usr/java/jdk1.8.0_281 mvn clean test-compile \
                        -Dflakime.flakeRate=${flakeRate} \
                        -Dflakime.strategy=vocabulary &> /dev/null ;
    echo "Build finish running mutation."
    JAVA_HOME=/usr/java/jdk1.8.0_281 mvn org.pitest:pitest-maven:mutationCoverage &> /dev/null;
    total_flake=$(wc -l target/flakime/* | grep -E 'total');
    total_killed=$(grep -E 'KILLED|TIMED_OUT' target/pit-reports/**/mutations.csv | wc -l);
    total_gen=$(grep -E '' target/pit-reports/**/mutations.csv | wc -l);
    str="${i},${total_gen},${total_flake},${total_killed}";
    echo "${str}";
    echo "${str}" >> output_$flakeRate.out;
done

